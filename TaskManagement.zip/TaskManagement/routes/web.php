<?php

use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/create', [TaskController::class, 'create']);
Route::post('/store', [TaskController::class, 'store']);
Route::get('/', [TaskController::class, 'index']);
Route::get('/edit/{id}', [TaskController::class, 'edit']);
Route::put('/update/{id}', [TaskController::class, 'update']);
Route::delete('/delete/{id}', [TaskController::class, 'destroy']);