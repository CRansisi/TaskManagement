<html>
    <head>
        <title>Add Tasks</title>
    </head>
    <body>
        <h1>Add From</h1>
        @if(session('success'))
            <div style="color: green; font-weight: bold;">
                {{ session('success')}}
            </div>
        @endif
        @if($errors->any())
            <div style="color: red;">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="/store">
            @csrf
            <label for="title">Title:</label>
            <input type="text" name="task_title"><br><br>
            <label for="description">Description:</label>
            <input type="text" name="task_description"><br><br>
            <label for="status">Status:</label>
                <select name="status" id="status">
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                </select>
            <br><br>
            <label for="due_date">Due date:</label>
            <input type="date" name="task_due_date"><br><br>
            <button type="submit">Save</button>
        </form>
    </body>
</html>