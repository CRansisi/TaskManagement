@extends('layouts.master')

@section('title','Home Page')

@section('content')
    <p>Welcome to the Home Page</p>
@endsection