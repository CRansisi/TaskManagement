<html>
    <head>
    </head>
    <body>
    <h1>Index Page</h1>
        <table border="1">
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Actions</th>
            </tr>

            @foreach($task as $task)
            <tr>
                <td>{{ $task->title }}</td>
                <td>{{ $task->description }}</td>
                <td>{{ $task->status }}</td>
                <td>{{ $task->due_date }}</td>
                <td>
                    <a href="/edit/{{ $task->id }}">Edit</a>
                    <form action="/delete/{{ $task->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button>Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </table>
    </body>
    <a href="{{url('/create')}}">Add new task</a>
</html>