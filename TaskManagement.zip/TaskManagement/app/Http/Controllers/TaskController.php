<?php

namespace App\Http\Controllers;
use App\Models\tasks;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function create()
    {
        return view('create');
    }
    public function index()
    {
        $task = tasks::get();
        return view('index', compact('task'));
    }
    public function store(Request $request)
    {
        
        $validated = $request->validate([
            'task_title' => 'required|max:100',
            'task_description' => 'required|max:100',
            'status' => 'required|in:Pending,In Progress,Completed',

            'task_due_date'=>'nullable|date'
        ]);

        $task = new tasks();
        $task->title = $request->task_title;
        $task->description = $request->task_description;
        $task->status = $request->status;
        $task->due_date = $request->task_due_date;

        $task->save();

        return back()->with(['success'=> 'Student created successfully!']);
    }
    public function edit($id)
    {
        $task = tasks::find($id);
        return view('edit', compact('task'));
    }
    public function update(Request $request, $id)
    {
        $task = Tasks::find($id);

        $validated = $request->validate([
            'task_title' => 'required|max:100',
            'task_description' => 'required|max:100',
            'status' => 'required|in:Pending,In Progress,Completed',
            'task_due_date'=>'nullable|date'
        ]);

        $task->title = $request->task_title;
        $task->description = $request->task_description;
        $task->status = $request->status;
        $task->due_date = $request->task_due_date;

        $task->save();

        return redirect('/')->with(['success'=> 'Task updated successfully!']);
    }
    public function destroy($id)
    {
        $task = Tasks::find($id);

        $task->delete();
        return redirect('/')->with(['success'=> 'Task deleted successfully!']);
    }

}
