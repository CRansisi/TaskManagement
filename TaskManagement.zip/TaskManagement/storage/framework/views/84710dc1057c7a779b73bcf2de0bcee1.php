<html>
    <head>
        <title>Edit form</title>
    </head>
    <body>
        <h1>Edit Page</h1>
        <?php if(session('success')): ?>
        <div style="color: green; font-weight: bold;">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div style="color: red;">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="/update/<?php echo e($task->id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="title">Title:</label>
            <input type="text" name="task_title" value=<?php echo e($task->title); ?>><br><br>
            <label for="description">Description:</label>
            <input type="text" name="task_description" value=<?php echo e($task->description); ?>><br><br>
            <label for="status">Status:</label>
                <select name="status" id="status" value=<?php echo e($task->status); ?>>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                </select>
            <br><br>
            <label for="due_date">Due date:</label>
            <input type="date" name="task_due_date" value=<?php echo e($task->due_date); ?>><br><br>
            <button type="submit">Save</button>
        </form>
    </body>
</html><?php /**PATH C:\xampp\htdocs\2022csc016\TaskManagement\resources\views/edit.blade.php ENDPATH**/ ?>