<html>
    <head>
    </head>
    <body>
    <h1>Index Page</h1>
        <table border="1">
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Actions</th>
            </tr>

            <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($task->title); ?></td>
                <td><?php echo e($task->description); ?></td>
                <td><?php echo e($task->status); ?></td>
                <td><?php echo e($task->due_date); ?></td>
                <td>
                    <a href="/edit/<?php echo e($task->id); ?>">Edit</a>
                    <form action="/delete/<?php echo e($task->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button>Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
    <a href="<?php echo e(url('/create')); ?>">Add new task</a>
</html><?php /**PATH C:\xampp\htdocs\2022csc016\TaskManagement\resources\views/index.blade.php ENDPATH**/ ?>